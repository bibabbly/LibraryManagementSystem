﻿namespace FirstDesktopApplication
{
    partial class SellingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellingForm));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties97 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties98 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties99 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties100 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties101 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties102 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties103 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties104 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle63 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties105 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties106 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties107 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties108 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties109 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties110 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties111 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties112 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.sellerNamee = new System.Windows.Forms.Label();
            this.dateLbl = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.prodDvDD = new Guna.UI2.WinForms.Guna2DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.proQty = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.proName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.billDVD = new Guna.UI2.WinForms.Guna2DataGridView();
            this.prodCategory = new System.Windows.Forms.ComboBox();
            this.prodPrice = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.billid = new Bunifu.UI.WinForms.BunifuTextBox();
            this.labpro = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelCash = new System.Windows.Forms.Label();
            this.orderDVD = new Guna.UI2.WinForms.Guna2DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prodDvDD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billDVD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderDVD)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AllowDrop = true;
            this.panel1.BackColor = System.Drawing.Color.DarkOrange;
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.orderDVD);
            this.panel1.Controls.Add(this.labelCash);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.sellerNamee);
            this.panel1.Controls.Add(this.dateLbl);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.prodDvDD);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.proQty);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.proName);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.billDVD);
            this.panel1.Controls.Add(this.prodCategory);
            this.panel1.Controls.Add(this.prodPrice);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.billid);
            this.panel1.Controls.Add(this.labpro);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(213, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1129, 663);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DarkOrange;
            this.button2.Location = new System.Drawing.Point(102, 244);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(193, 42);
            this.button2.TabIndex = 32;
            this.button2.Text = "ADD PRODUCT";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // sellerNamee
            // 
            this.sellerNamee.AutoSize = true;
            this.sellerNamee.BackColor = System.Drawing.Color.DarkOrange;
            this.sellerNamee.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sellerNamee.ForeColor = System.Drawing.Color.White;
            this.sellerNamee.Location = new System.Drawing.Point(46, 13);
            this.sellerNamee.Name = "sellerNamee";
            this.sellerNamee.Size = new System.Drawing.Size(148, 27);
            this.sellerNamee.TabIndex = 31;
            this.sellerNamee.Text = "Seller Name";
            // 
            // dateLbl
            // 
            this.dateLbl.AutoSize = true;
            this.dateLbl.BackColor = System.Drawing.Color.DarkOrange;
            this.dateLbl.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateLbl.ForeColor = System.Drawing.Color.White;
            this.dateLbl.Location = new System.Drawing.Point(937, 13);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(67, 27);
            this.dateLbl.TabIndex = 30;
            this.dateLbl.Text = "DATE";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.DarkOrange;
            this.button5.Location = new System.Drawing.Point(812, 562);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(122, 48);
            this.button5.TabIndex = 29;
            this.button5.Text = "DELETE";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.DarkOrange;
            this.button4.Location = new System.Drawing.Point(672, 562);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 48);
            this.button4.TabIndex = 28;
            this.button4.Text = "PRINT ";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DarkOrange;
            this.button3.Location = new System.Drawing.Point(512, 562);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 48);
            this.button3.TabIndex = 27;
            this.button3.Text = "ADD";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // prodDvDD
            // 
            dataGridViewCellStyle58.BackColor = System.Drawing.Color.White;
            this.prodDvDD.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle58;
            this.prodDvDD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.prodDvDD.BackgroundColor = System.Drawing.Color.White;
            this.prodDvDD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.prodDvDD.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.prodDvDD.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle59.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.prodDvDD.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle59;
            this.prodDvDD.ColumnHeadersHeight = 25;
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle60.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle60.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle60.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle60.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.prodDvDD.DefaultCellStyle = dataGridViewCellStyle60;
            this.prodDvDD.EnableHeadersVisualStyles = false;
            this.prodDvDD.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.prodDvDD.Location = new System.Drawing.Point(13, 334);
            this.prodDvDD.Name = "prodDvDD";
            this.prodDvDD.RowHeadersVisible = false;
            this.prodDvDD.RowHeadersWidth = 51;
            this.prodDvDD.RowTemplate.Height = 24;
            this.prodDvDD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.prodDvDD.Size = new System.Drawing.Size(314, 314);
            this.prodDvDD.TabIndex = 26;
            this.prodDvDD.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.prodDvDD.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.prodDvDD.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.prodDvDD.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.prodDvDD.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.prodDvDD.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.prodDvDD.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.prodDvDD.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.prodDvDD.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.prodDvDD.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.prodDvDD.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.prodDvDD.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.prodDvDD.ThemeStyle.HeaderStyle.Height = 25;
            this.prodDvDD.ThemeStyle.ReadOnly = false;
            this.prodDvDD.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.prodDvDD.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.prodDvDD.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.prodDvDD.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.prodDvDD.ThemeStyle.RowsStyle.Height = 24;
            this.prodDvDD.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.prodDvDD.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.prodDvDD.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.prodDvDD_CellContentClick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkOrange;
            this.button1.Location = new System.Drawing.Point(202, 292);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 36);
            this.button1.TabIndex = 25;
            this.button1.Text = "REFRESH";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // proQty
            // 
            this.proQty.AcceptsReturn = false;
            this.proQty.AcceptsTab = false;
            this.proQty.AnimationSpeed = 200;
            this.proQty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.proQty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.proQty.AutoSizeHeight = true;
            this.proQty.BackColor = System.Drawing.Color.DarkOrange;
            this.proQty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("proQty.BackgroundImage")));
            this.proQty.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.proQty.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.proQty.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.proQty.BorderColorIdle = System.Drawing.Color.White;
            this.proQty.BorderRadius = 10;
            this.proQty.BorderThickness = 4;
            this.proQty.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.proQty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.proQty.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.proQty.DefaultText = "";
            this.proQty.FillColor = System.Drawing.Color.DarkOrange;
            this.proQty.HideSelection = true;
            this.proQty.IconLeft = null;
            this.proQty.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.proQty.IconPadding = 10;
            this.proQty.IconRight = null;
            this.proQty.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.proQty.Lines = new string[0];
            this.proQty.Location = new System.Drawing.Point(113, 200);
            this.proQty.MaxLength = 32767;
            this.proQty.MinimumSize = new System.Drawing.Size(1, 1);
            this.proQty.Modified = false;
            this.proQty.Multiline = false;
            this.proQty.Name = "proQty";
            stateProperties97.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties97.FillColor = System.Drawing.Color.Empty;
            stateProperties97.ForeColor = System.Drawing.Color.Empty;
            stateProperties97.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.proQty.OnActiveState = stateProperties97;
            stateProperties98.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties98.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties98.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties98.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.proQty.OnDisabledState = stateProperties98;
            stateProperties99.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties99.FillColor = System.Drawing.Color.Empty;
            stateProperties99.ForeColor = System.Drawing.Color.Empty;
            stateProperties99.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.proQty.OnHoverState = stateProperties99;
            stateProperties100.BorderColor = System.Drawing.Color.White;
            stateProperties100.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties100.ForeColor = System.Drawing.Color.Empty;
            stateProperties100.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.proQty.OnIdleState = stateProperties100;
            this.proQty.Padding = new System.Windows.Forms.Padding(3);
            this.proQty.PasswordChar = '\0';
            this.proQty.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.proQty.PlaceholderText = "Enter text";
            this.proQty.ReadOnly = false;
            this.proQty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.proQty.SelectedText = "";
            this.proQty.SelectionLength = 0;
            this.proQty.SelectionStart = 0;
            this.proQty.ShortcutsEnabled = true;
            this.proQty.Size = new System.Drawing.Size(143, 38);
            this.proQty.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.proQty.TabIndex = 24;
            this.proQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.proQty.TextMarginBottom = 0;
            this.proQty.TextMarginLeft = 3;
            this.proQty.TextMarginTop = 1;
            this.proQty.TextPlaceholder = "Enter text";
            this.proQty.UseSystemPasswordChar = false;
            this.proQty.WordWrap = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkOrange;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(8, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 22);
            this.label3.TabIndex = 23;
            this.label3.Text = "Quantity";
            // 
            // proName
            // 
            this.proName.AcceptsReturn = false;
            this.proName.AcceptsTab = false;
            this.proName.AnimationSpeed = 200;
            this.proName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.proName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.proName.AutoSizeHeight = true;
            this.proName.BackColor = System.Drawing.Color.DarkOrange;
            this.proName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("proName.BackgroundImage")));
            this.proName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.proName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.proName.BorderColorHover = System.Drawing.Color.White;
            this.proName.BorderColorIdle = System.Drawing.Color.White;
            this.proName.BorderRadius = 10;
            this.proName.BorderThickness = 4;
            this.proName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.proName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.proName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.proName.DefaultText = "";
            this.proName.FillColor = System.Drawing.Color.DarkOrange;
            this.proName.HideSelection = true;
            this.proName.IconLeft = null;
            this.proName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.proName.IconPadding = 10;
            this.proName.IconRight = null;
            this.proName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.proName.Lines = new string[0];
            this.proName.Location = new System.Drawing.Point(113, 94);
            this.proName.MaxLength = 32767;
            this.proName.MinimumSize = new System.Drawing.Size(1, 1);
            this.proName.Modified = false;
            this.proName.Multiline = false;
            this.proName.Name = "proName";
            stateProperties101.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties101.FillColor = System.Drawing.Color.Empty;
            stateProperties101.ForeColor = System.Drawing.Color.Empty;
            stateProperties101.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.proName.OnActiveState = stateProperties101;
            stateProperties102.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties102.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties102.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties102.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.proName.OnDisabledState = stateProperties102;
            stateProperties103.BorderColor = System.Drawing.Color.White;
            stateProperties103.FillColor = System.Drawing.Color.Empty;
            stateProperties103.ForeColor = System.Drawing.Color.Empty;
            stateProperties103.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.proName.OnHoverState = stateProperties103;
            stateProperties104.BorderColor = System.Drawing.Color.White;
            stateProperties104.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties104.ForeColor = System.Drawing.Color.Empty;
            stateProperties104.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.proName.OnIdleState = stateProperties104;
            this.proName.Padding = new System.Windows.Forms.Padding(3);
            this.proName.PasswordChar = '\0';
            this.proName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.proName.PlaceholderText = "Enter text";
            this.proName.ReadOnly = false;
            this.proName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.proName.SelectedText = "";
            this.proName.SelectionLength = 0;
            this.proName.SelectionStart = 0;
            this.proName.ShortcutsEnabled = true;
            this.proName.Size = new System.Drawing.Size(143, 34);
            this.proName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.proName.TabIndex = 22;
            this.proName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.proName.TextMarginBottom = 0;
            this.proName.TextMarginLeft = 3;
            this.proName.TextMarginTop = 1;
            this.proName.TextPlaceholder = "Enter text";
            this.proName.UseSystemPasswordChar = false;
            this.proName.WordWrap = true;
            this.proName.TextChanged += new System.EventHandler(this.bunifuTextBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkOrange;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(5, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 22);
            this.label2.TabIndex = 21;
            this.label2.Text = "ProdName";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // billDVD
            // 
            dataGridViewCellStyle61.BackColor = System.Drawing.Color.White;
            this.billDVD.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle61;
            this.billDVD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.billDVD.BackgroundColor = System.Drawing.Color.White;
            this.billDVD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.billDVD.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.billDVD.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle62.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle62.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle62.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle62.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.billDVD.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle62;
            this.billDVD.ColumnHeadersHeight = 25;
            dataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle63.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle63.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle63.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle63.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle63.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle63.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.billDVD.DefaultCellStyle = dataGridViewCellStyle63;
            this.billDVD.EnableHeadersVisualStyles = false;
            this.billDVD.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.billDVD.Location = new System.Drawing.Point(432, 370);
            this.billDVD.Name = "billDVD";
            this.billDVD.RowHeadersVisible = false;
            this.billDVD.RowHeadersWidth = 51;
            this.billDVD.RowTemplate.Height = 24;
            this.billDVD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.billDVD.Size = new System.Drawing.Size(630, 154);
            this.billDVD.TabIndex = 18;
            this.billDVD.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.billDVD.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.billDVD.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.billDVD.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.billDVD.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.billDVD.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.billDVD.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.billDVD.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.billDVD.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.billDVD.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.billDVD.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.billDVD.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.billDVD.ThemeStyle.HeaderStyle.Height = 25;
            this.billDVD.ThemeStyle.ReadOnly = false;
            this.billDVD.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.billDVD.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.billDVD.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.billDVD.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.billDVD.ThemeStyle.RowsStyle.Height = 24;
            this.billDVD.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.billDVD.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.billDVD.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.billDVD_CellContentClick);
            // 
            // prodCategory
            // 
            this.prodCategory.DisplayMember = "catName";
            this.prodCategory.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prodCategory.ForeColor = System.Drawing.Color.DarkOrange;
            this.prodCategory.FormattingEnabled = true;
            this.prodCategory.Location = new System.Drawing.Point(12, 292);
            this.prodCategory.Name = "prodCategory";
            this.prodCategory.Size = new System.Drawing.Size(182, 29);
            this.prodCategory.TabIndex = 15;
            this.prodCategory.Text = "Select Category";
            this.prodCategory.ValueMember = "catName";
            this.prodCategory.SelectionChangeCommitted += new System.EventHandler(this.prodCategory_SelectionChangeCommitted);
            // 
            // prodPrice
            // 
            this.prodPrice.AcceptsReturn = false;
            this.prodPrice.AcceptsTab = false;
            this.prodPrice.AnimationSpeed = 200;
            this.prodPrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.prodPrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.prodPrice.AutoSizeHeight = true;
            this.prodPrice.BackColor = System.Drawing.Color.DarkOrange;
            this.prodPrice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("prodPrice.BackgroundImage")));
            this.prodPrice.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.prodPrice.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.prodPrice.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.prodPrice.BorderColorIdle = System.Drawing.Color.White;
            this.prodPrice.BorderRadius = 10;
            this.prodPrice.BorderThickness = 4;
            this.prodPrice.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.prodPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.prodPrice.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.prodPrice.DefaultText = "";
            this.prodPrice.FillColor = System.Drawing.Color.DarkOrange;
            this.prodPrice.HideSelection = true;
            this.prodPrice.IconLeft = null;
            this.prodPrice.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodPrice.IconPadding = 10;
            this.prodPrice.IconRight = null;
            this.prodPrice.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodPrice.Lines = new string[0];
            this.prodPrice.Location = new System.Drawing.Point(113, 137);
            this.prodPrice.MaxLength = 32767;
            this.prodPrice.MinimumSize = new System.Drawing.Size(1, 1);
            this.prodPrice.Modified = false;
            this.prodPrice.Multiline = false;
            this.prodPrice.Name = "prodPrice";
            stateProperties105.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties105.FillColor = System.Drawing.Color.Empty;
            stateProperties105.ForeColor = System.Drawing.Color.Empty;
            stateProperties105.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodPrice.OnActiveState = stateProperties105;
            stateProperties106.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties106.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties106.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties106.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.prodPrice.OnDisabledState = stateProperties106;
            stateProperties107.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties107.FillColor = System.Drawing.Color.Empty;
            stateProperties107.ForeColor = System.Drawing.Color.Empty;
            stateProperties107.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodPrice.OnHoverState = stateProperties107;
            stateProperties108.BorderColor = System.Drawing.Color.White;
            stateProperties108.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties108.ForeColor = System.Drawing.Color.Empty;
            stateProperties108.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodPrice.OnIdleState = stateProperties108;
            this.prodPrice.Padding = new System.Windows.Forms.Padding(3);
            this.prodPrice.PasswordChar = '\0';
            this.prodPrice.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.prodPrice.PlaceholderText = "Enter text";
            this.prodPrice.ReadOnly = false;
            this.prodPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.prodPrice.SelectedText = "";
            this.prodPrice.SelectionLength = 0;
            this.prodPrice.SelectionStart = 0;
            this.prodPrice.ShortcutsEnabled = true;
            this.prodPrice.Size = new System.Drawing.Size(143, 38);
            this.prodPrice.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.prodPrice.TabIndex = 13;
            this.prodPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.prodPrice.TextMarginBottom = 0;
            this.prodPrice.TextMarginLeft = 3;
            this.prodPrice.TextMarginTop = 1;
            this.prodPrice.TextPlaceholder = "Enter text";
            this.prodPrice.UseSystemPasswordChar = false;
            this.prodPrice.WordWrap = true;
            this.prodPrice.TextChanged += new System.EventHandler(this.prodPrice_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkOrange;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(8, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 22);
            this.label5.TabIndex = 12;
            this.label5.Text = "PRICE";
            // 
            // billid
            // 
            this.billid.AcceptsReturn = false;
            this.billid.AcceptsTab = false;
            this.billid.AnimationSpeed = 200;
            this.billid.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.billid.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.billid.AutoSizeHeight = true;
            this.billid.BackColor = System.Drawing.Color.DarkOrange;
            this.billid.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("billid.BackgroundImage")));
            this.billid.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.billid.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.billid.BorderColorHover = System.Drawing.Color.White;
            this.billid.BorderColorIdle = System.Drawing.Color.White;
            this.billid.BorderRadius = 10;
            this.billid.BorderThickness = 4;
            this.billid.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.billid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.billid.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.billid.DefaultText = "";
            this.billid.FillColor = System.Drawing.Color.DarkOrange;
            this.billid.HideSelection = true;
            this.billid.IconLeft = null;
            this.billid.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.billid.IconPadding = 10;
            this.billid.IconRight = null;
            this.billid.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.billid.Lines = new string[0];
            this.billid.Location = new System.Drawing.Point(113, 44);
            this.billid.MaxLength = 32767;
            this.billid.MinimumSize = new System.Drawing.Size(1, 1);
            this.billid.Modified = false;
            this.billid.Multiline = false;
            this.billid.Name = "billid";
            stateProperties109.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties109.FillColor = System.Drawing.Color.Empty;
            stateProperties109.ForeColor = System.Drawing.Color.Empty;
            stateProperties109.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.billid.OnActiveState = stateProperties109;
            stateProperties110.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties110.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties110.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties110.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.billid.OnDisabledState = stateProperties110;
            stateProperties111.BorderColor = System.Drawing.Color.White;
            stateProperties111.FillColor = System.Drawing.Color.Empty;
            stateProperties111.ForeColor = System.Drawing.Color.Empty;
            stateProperties111.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.billid.OnHoverState = stateProperties111;
            stateProperties112.BorderColor = System.Drawing.Color.White;
            stateProperties112.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties112.ForeColor = System.Drawing.Color.Empty;
            stateProperties112.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.billid.OnIdleState = stateProperties112;
            this.billid.Padding = new System.Windows.Forms.Padding(3);
            this.billid.PasswordChar = '\0';
            this.billid.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.billid.PlaceholderText = "Enter text";
            this.billid.ReadOnly = false;
            this.billid.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.billid.SelectedText = "";
            this.billid.SelectionLength = 0;
            this.billid.SelectionStart = 0;
            this.billid.ShortcutsEnabled = true;
            this.billid.Size = new System.Drawing.Size(143, 34);
            this.billid.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.billid.TabIndex = 7;
            this.billid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.billid.TextMarginBottom = 0;
            this.billid.TextMarginLeft = 3;
            this.billid.TextMarginTop = 1;
            this.billid.TextPlaceholder = "Enter text";
            this.billid.UseSystemPasswordChar = false;
            this.billid.WordWrap = true;
            // 
            // labpro
            // 
            this.labpro.AutoSize = true;
            this.labpro.BackColor = System.Drawing.Color.DarkOrange;
            this.labpro.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labpro.ForeColor = System.Drawing.Color.White;
            this.labpro.Location = new System.Drawing.Point(8, 55);
            this.labpro.Name = "labpro";
            this.labpro.Size = new System.Drawing.Size(72, 23);
            this.labpro.TabIndex = 6;
            this.labpro.Text = "BILL ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkOrange;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(454, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 37);
            this.label1.TabIndex = 5;
            this.label1.Text = "SELLING";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkOrange;
            this.label8.Location = new System.Drawing.Point(1305, -1);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 37);
            this.label8.TabIndex = 21;
            this.label8.Text = "X";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkOrange;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(592, 259);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 27);
            this.label6.TabIndex = 33;
            this.label6.Text = " Amount  RWF";
            // 
            // labelCash
            // 
            this.labelCash.AutoSize = true;
            this.labelCash.BackColor = System.Drawing.Color.DarkOrange;
            this.labelCash.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCash.ForeColor = System.Drawing.Color.White;
            this.labelCash.Location = new System.Drawing.Point(762, 259);
            this.labelCash.Name = "labelCash";
            this.labelCash.Size = new System.Drawing.Size(57, 27);
            this.labelCash.TabIndex = 34;
            this.labelCash.Text = "RWF";
            // 
            // orderDVD
            // 
            dataGridViewCellStyle55.BackColor = System.Drawing.Color.White;
            this.orderDVD.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle55;
            this.orderDVD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.orderDVD.BackgroundColor = System.Drawing.Color.White;
            this.orderDVD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.orderDVD.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.orderDVD.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle56.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle56.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle56.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle56.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.orderDVD.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle56;
            this.orderDVD.ColumnHeadersHeight = 25;
            this.orderDVD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.PName,
            this.Price,
            this.Quantity,
            this.Total});
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.orderDVD.DefaultCellStyle = dataGridViewCellStyle57;
            this.orderDVD.EnableHeadersVisualStyles = false;
            this.orderDVD.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.orderDVD.Location = new System.Drawing.Point(432, 66);
            this.orderDVD.Name = "orderDVD";
            this.orderDVD.RowHeadersVisible = false;
            this.orderDVD.RowHeadersWidth = 51;
            this.orderDVD.RowTemplate.Height = 24;
            this.orderDVD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.orderDVD.Size = new System.Drawing.Size(630, 172);
            this.orderDVD.TabIndex = 35;
            this.orderDVD.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.orderDVD.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.orderDVD.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.orderDVD.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.orderDVD.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.orderDVD.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.orderDVD.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.orderDVD.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.orderDVD.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.orderDVD.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.orderDVD.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.orderDVD.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.orderDVD.ThemeStyle.HeaderStyle.Height = 25;
            this.orderDVD.ThemeStyle.ReadOnly = false;
            this.orderDVD.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.orderDVD.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.orderDVD.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.orderDVD.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.orderDVD.ThemeStyle.RowsStyle.Height = 24;
            this.orderDVD.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.orderDVD.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.DarkOrange;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(665, 321);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(149, 37);
            this.label9.TabIndex = 36;
            this.label9.Text = "SELLS LIST";
            // 
            // ID
            // 
            this.ID.HeaderText = "ProdId";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            // 
            // PName
            // 
            this.PName.HeaderText = "ProdName";
            this.PName.MinimumWidth = 6;
            this.PName.Name = "PName";
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            // 
            // Quantity
            // 
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.MinimumWidth = 6;
            this.Quantity.Name = "Quantity";
            // 
            // Total
            // 
            this.Total.HeaderText = "Total";
            this.Total.MinimumWidth = 6;
            this.Total.Name = "Total";
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkOrange;
            this.label4.Location = new System.Drawing.Point(43, 622);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 37);
            this.label4.TabIndex = 37;
            this.label4.Text = "Logout";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // SellingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1393, 728);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SellingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SellingForm";
            this.Load += new System.EventHandler(this.SellingForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prodDvDD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billDVD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderDVD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2DataGridView billDVD;
        private System.Windows.Forms.ComboBox prodCategory;
        private Bunifu.UI.WinForms.BunifuTextBox prodPrice;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuTextBox billid;
        private System.Windows.Forms.Label labpro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private Bunifu.UI.WinForms.BunifuTextBox proName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private Guna.UI2.WinForms.Guna2DataGridView prodDvDD;
        private System.Windows.Forms.Button button1;
        private Bunifu.UI.WinForms.BunifuTextBox proQty;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label sellerNamee;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2DataGridView orderDVD;
        private System.Windows.Forms.Label labelCash;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Label label4;
    }
}