﻿namespace FirstDesktopApplication
{
    partial class SellerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellerForm));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sPass = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.sellerDVD = new Guna.UI2.WinForms.Guna2DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.sTel = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.sEmail = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.sName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.sId = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Seller = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sellerDVD)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkOrange;
            this.panel1.Controls.Add(this.sPass);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.sellerDVD);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.sTel);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.sEmail);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.sName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.sId);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(188, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1129, 603);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // sPass
            // 
            this.sPass.AcceptsReturn = false;
            this.sPass.AcceptsTab = false;
            this.sPass.AnimationSpeed = 200;
            this.sPass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.sPass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.sPass.AutoSizeHeight = true;
            this.sPass.BackColor = System.Drawing.Color.DarkOrange;
            this.sPass.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sPass.BackgroundImage")));
            this.sPass.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.sPass.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.sPass.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.sPass.BorderColorIdle = System.Drawing.Color.White;
            this.sPass.BorderRadius = 10;
            this.sPass.BorderThickness = 4;
            this.sPass.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.sPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sPass.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.sPass.DefaultText = "";
            this.sPass.FillColor = System.Drawing.Color.DarkOrange;
            this.sPass.HideSelection = true;
            this.sPass.IconLeft = null;
            this.sPass.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.sPass.IconPadding = 10;
            this.sPass.IconRight = null;
            this.sPass.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.sPass.Lines = new string[0];
            this.sPass.Location = new System.Drawing.Point(149, 296);
            this.sPass.MaxLength = 32767;
            this.sPass.MinimumSize = new System.Drawing.Size(1, 1);
            this.sPass.Modified = false;
            this.sPass.Multiline = false;
            this.sPass.Name = "sPass";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sPass.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.sPass.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sPass.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.White;
            stateProperties4.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sPass.OnIdleState = stateProperties4;
            this.sPass.Padding = new System.Windows.Forms.Padding(3);
            this.sPass.PasswordChar = '\0';
            this.sPass.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.sPass.PlaceholderText = "Enter text";
            this.sPass.ReadOnly = false;
            this.sPass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sPass.SelectedText = "";
            this.sPass.SelectionLength = 0;
            this.sPass.SelectionStart = 0;
            this.sPass.ShortcutsEnabled = true;
            this.sPass.Size = new System.Drawing.Size(181, 38);
            this.sPass.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.sPass.TabIndex = 22;
            this.sPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sPass.TextMarginBottom = 0;
            this.sPass.TextMarginLeft = 3;
            this.sPass.TextMarginTop = 1;
            this.sPass.TextPlaceholder = "Enter text";
            this.sPass.UseSystemPasswordChar = false;
            this.sPass.WordWrap = true;
            this.sPass.TextChanged += new System.EventHandler(this.bunifuTextBox5_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkOrange;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(3, 307);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 27);
            this.label6.TabIndex = 21;
            this.label6.Text = "PASSWORD";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.DarkOrange;
            this.button6.Location = new System.Drawing.Point(884, 67);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(125, 36);
            this.button6.TabIndex = 20;
            this.button6.Text = "REFRESH";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.ForeColor = System.Drawing.Color.DarkOrange;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Admin",
            "Seller"});
            this.comboBox2.Location = new System.Drawing.Point(652, 67);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(213, 29);
            this.comboBox2.TabIndex = 19;
            this.comboBox2.Text = "Select Role";
            // 
            // sellerDVD
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.sellerDVD.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.sellerDVD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.sellerDVD.BackgroundColor = System.Drawing.Color.White;
            this.sellerDVD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.sellerDVD.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.sellerDVD.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.sellerDVD.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.sellerDVD.ColumnHeadersHeight = 25;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.sellerDVD.DefaultCellStyle = dataGridViewCellStyle3;
            this.sellerDVD.EnableHeadersVisualStyles = false;
            this.sellerDVD.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.sellerDVD.Location = new System.Drawing.Point(442, 114);
            this.sellerDVD.Name = "sellerDVD";
            this.sellerDVD.RowHeadersVisible = false;
            this.sellerDVD.RowHeadersWidth = 51;
            this.sellerDVD.RowTemplate.Height = 24;
            this.sellerDVD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.sellerDVD.Size = new System.Drawing.Size(630, 468);
            this.sellerDVD.TabIndex = 18;
            this.sellerDVD.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.sellerDVD.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.sellerDVD.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.sellerDVD.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.sellerDVD.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.sellerDVD.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.sellerDVD.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.sellerDVD.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.sellerDVD.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.sellerDVD.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.sellerDVD.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.sellerDVD.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.sellerDVD.ThemeStyle.HeaderStyle.Height = 25;
            this.sellerDVD.ThemeStyle.ReadOnly = false;
            this.sellerDVD.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.sellerDVD.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.sellerDVD.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.sellerDVD.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.sellerDVD.ThemeStyle.RowsStyle.Height = 24;
            this.sellerDVD.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.sellerDVD.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.sellerDVD.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.sellerDVD_CellContentClick);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.DarkOrange;
            this.button5.Location = new System.Drawing.Point(231, 355);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 48);
            this.button5.TabIndex = 17;
            this.button5.Text = "DELETE";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.DarkOrange;
            this.button4.Location = new System.Drawing.Point(113, 355);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 48);
            this.button4.TabIndex = 16;
            this.button4.Text = "EDIT";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DarkOrange;
            this.button3.Location = new System.Drawing.Point(13, 355);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 48);
            this.button3.TabIndex = 15;
            this.button3.Text = "ADD";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // sTel
            // 
            this.sTel.AcceptsReturn = false;
            this.sTel.AcceptsTab = false;
            this.sTel.AnimationSpeed = 200;
            this.sTel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.sTel.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.sTel.AutoSizeHeight = true;
            this.sTel.BackColor = System.Drawing.Color.DarkOrange;
            this.sTel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sTel.BackgroundImage")));
            this.sTel.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.sTel.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.sTel.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.sTel.BorderColorIdle = System.Drawing.Color.White;
            this.sTel.BorderRadius = 10;
            this.sTel.BorderThickness = 4;
            this.sTel.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.sTel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sTel.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.sTel.DefaultText = "";
            this.sTel.FillColor = System.Drawing.Color.DarkOrange;
            this.sTel.HideSelection = true;
            this.sTel.IconLeft = null;
            this.sTel.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.sTel.IconPadding = 10;
            this.sTel.IconRight = null;
            this.sTel.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.sTel.Lines = new string[0];
            this.sTel.Location = new System.Drawing.Point(149, 232);
            this.sTel.MaxLength = 32767;
            this.sTel.MinimumSize = new System.Drawing.Size(1, 1);
            this.sTel.Modified = false;
            this.sTel.Multiline = false;
            this.sTel.Name = "sTel";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sTel.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.sTel.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sTel.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.White;
            stateProperties8.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sTel.OnIdleState = stateProperties8;
            this.sTel.Padding = new System.Windows.Forms.Padding(3);
            this.sTel.PasswordChar = '\0';
            this.sTel.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.sTel.PlaceholderText = "Enter text";
            this.sTel.ReadOnly = false;
            this.sTel.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sTel.SelectedText = "";
            this.sTel.SelectionLength = 0;
            this.sTel.SelectionStart = 0;
            this.sTel.ShortcutsEnabled = true;
            this.sTel.Size = new System.Drawing.Size(181, 38);
            this.sTel.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.sTel.TabIndex = 13;
            this.sTel.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sTel.TextMarginBottom = 0;
            this.sTel.TextMarginLeft = 3;
            this.sTel.TextMarginTop = 1;
            this.sTel.TextPlaceholder = "Enter text";
            this.sTel.UseSystemPasswordChar = false;
            this.sTel.WordWrap = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkOrange;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 27);
            this.label5.TabIndex = 12;
            this.label5.Text = "TEL";
            // 
            // sEmail
            // 
            this.sEmail.AcceptsReturn = false;
            this.sEmail.AcceptsTab = false;
            this.sEmail.AnimationSpeed = 200;
            this.sEmail.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.sEmail.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.sEmail.AutoSizeHeight = true;
            this.sEmail.BackColor = System.Drawing.Color.DarkOrange;
            this.sEmail.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sEmail.BackgroundImage")));
            this.sEmail.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.sEmail.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.sEmail.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.sEmail.BorderColorIdle = System.Drawing.Color.White;
            this.sEmail.BorderRadius = 10;
            this.sEmail.BorderThickness = 4;
            this.sEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.sEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sEmail.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.sEmail.DefaultText = "";
            this.sEmail.FillColor = System.Drawing.Color.DarkOrange;
            this.sEmail.HideSelection = true;
            this.sEmail.IconLeft = null;
            this.sEmail.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.sEmail.IconPadding = 10;
            this.sEmail.IconRight = null;
            this.sEmail.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.sEmail.Lines = new string[0];
            this.sEmail.Location = new System.Drawing.Point(149, 188);
            this.sEmail.MaxLength = 32767;
            this.sEmail.MinimumSize = new System.Drawing.Size(1, 1);
            this.sEmail.Modified = false;
            this.sEmail.Multiline = false;
            this.sEmail.Name = "sEmail";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sEmail.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.sEmail.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sEmail.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.White;
            stateProperties12.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sEmail.OnIdleState = stateProperties12;
            this.sEmail.Padding = new System.Windows.Forms.Padding(3);
            this.sEmail.PasswordChar = '\0';
            this.sEmail.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.sEmail.PlaceholderText = "Enter text";
            this.sEmail.ReadOnly = false;
            this.sEmail.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sEmail.SelectedText = "";
            this.sEmail.SelectionLength = 0;
            this.sEmail.SelectionStart = 0;
            this.sEmail.ShortcutsEnabled = true;
            this.sEmail.Size = new System.Drawing.Size(181, 38);
            this.sEmail.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.sEmail.TabIndex = 11;
            this.sEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sEmail.TextMarginBottom = 0;
            this.sEmail.TextMarginLeft = 3;
            this.sEmail.TextMarginTop = 1;
            this.sEmail.TextPlaceholder = "Enter text";
            this.sEmail.UseSystemPasswordChar = false;
            this.sEmail.WordWrap = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkOrange;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 27);
            this.label4.TabIndex = 10;
            this.label4.Text = "EMAIL";
            // 
            // sName
            // 
            this.sName.AcceptsReturn = false;
            this.sName.AcceptsTab = false;
            this.sName.AnimationSpeed = 200;
            this.sName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.sName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.sName.AutoSizeHeight = true;
            this.sName.BackColor = System.Drawing.Color.DarkOrange;
            this.sName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sName.BackgroundImage")));
            this.sName.BorderColorActive = System.Drawing.Color.White;
            this.sName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.sName.BorderColorHover = System.Drawing.Color.White;
            this.sName.BorderColorIdle = System.Drawing.Color.White;
            this.sName.BorderRadius = 10;
            this.sName.BorderThickness = 4;
            this.sName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.sName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.sName.DefaultText = "";
            this.sName.FillColor = System.Drawing.Color.DarkOrange;
            this.sName.HideSelection = true;
            this.sName.IconLeft = null;
            this.sName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.sName.IconPadding = 10;
            this.sName.IconRight = null;
            this.sName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.sName.Lines = new string[0];
            this.sName.Location = new System.Drawing.Point(149, 132);
            this.sName.MaxLength = 32767;
            this.sName.MinimumSize = new System.Drawing.Size(1, 1);
            this.sName.Modified = false;
            this.sName.Multiline = false;
            this.sName.Name = "sName";
            stateProperties13.BorderColor = System.Drawing.Color.White;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sName.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.sName.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.White;
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sName.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.White;
            stateProperties16.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sName.OnIdleState = stateProperties16;
            this.sName.Padding = new System.Windows.Forms.Padding(3);
            this.sName.PasswordChar = '\0';
            this.sName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.sName.PlaceholderText = "Enter text";
            this.sName.ReadOnly = false;
            this.sName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sName.SelectedText = "";
            this.sName.SelectionLength = 0;
            this.sName.SelectionStart = 0;
            this.sName.ShortcutsEnabled = true;
            this.sName.Size = new System.Drawing.Size(181, 38);
            this.sName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.sName.TabIndex = 9;
            this.sName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sName.TextMarginBottom = 0;
            this.sName.TextMarginLeft = 3;
            this.sName.TextMarginTop = 1;
            this.sName.TextPlaceholder = "Enter text";
            this.sName.UseSystemPasswordChar = false;
            this.sName.WordWrap = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkOrange;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 27);
            this.label3.TabIndex = 8;
            this.label3.Text = "NAME";
            // 
            // sId
            // 
            this.sId.AcceptsReturn = false;
            this.sId.AcceptsTab = false;
            this.sId.AnimationSpeed = 200;
            this.sId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.sId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.sId.AutoSizeHeight = true;
            this.sId.BackColor = System.Drawing.Color.DarkOrange;
            this.sId.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sId.BackgroundImage")));
            this.sId.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.sId.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.sId.BorderColorHover = System.Drawing.Color.White;
            this.sId.BorderColorIdle = System.Drawing.Color.White;
            this.sId.BorderRadius = 10;
            this.sId.BorderThickness = 4;
            this.sId.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.sId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sId.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.sId.DefaultText = "";
            this.sId.FillColor = System.Drawing.Color.DarkOrange;
            this.sId.HideSelection = true;
            this.sId.IconLeft = null;
            this.sId.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.sId.IconPadding = 10;
            this.sId.IconRight = null;
            this.sId.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.sId.Lines = new string[0];
            this.sId.Location = new System.Drawing.Point(149, 78);
            this.sId.MaxLength = 32767;
            this.sId.MinimumSize = new System.Drawing.Size(1, 1);
            this.sId.Modified = false;
            this.sId.Multiline = false;
            this.sId.Name = "sId";
            stateProperties17.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sId.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.sId.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.White;
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sId.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.White;
            stateProperties20.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sId.OnIdleState = stateProperties20;
            this.sId.Padding = new System.Windows.Forms.Padding(3);
            this.sId.PasswordChar = '\0';
            this.sId.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.sId.PlaceholderText = "Enter text";
            this.sId.ReadOnly = false;
            this.sId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sId.SelectedText = "";
            this.sId.SelectionLength = 0;
            this.sId.SelectionStart = 0;
            this.sId.ShortcutsEnabled = true;
            this.sId.Size = new System.Drawing.Size(181, 38);
            this.sId.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.sId.TabIndex = 7;
            this.sId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sId.TextMarginBottom = 0;
            this.sId.TextMarginLeft = 3;
            this.sId.TextMarginTop = 1;
            this.sId.TextPlaceholder = "Enter text";
            this.sId.UseSystemPasswordChar = false;
            this.sId.WordWrap = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkOrange;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 27);
            this.label2.TabIndex = 6;
            this.label2.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkOrange;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(435, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(250, 37);
            this.label1.TabIndex = 5;
            this.label1.Text = "MANAGE SELLER";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkOrange;
            this.label8.Location = new System.Drawing.Point(1280, -2);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 37);
            this.label8.TabIndex = 15;
            this.label8.Text = "X";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkOrange;
            this.button1.Location = new System.Drawing.Point(32, 209);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 50);
            this.button1.TabIndex = 18;
            this.button1.Text = "Selling";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DarkOrange;
            this.button2.Location = new System.Drawing.Point(32, 153);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 50);
            this.button2.TabIndex = 17;
            this.button2.Text = "Categories";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Seller
            // 
            this.Seller.BackColor = System.Drawing.SystemColors.Control;
            this.Seller.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seller.ForeColor = System.Drawing.Color.DarkOrange;
            this.Seller.Location = new System.Drawing.Point(32, 99);
            this.Seller.Name = "Seller";
            this.Seller.Size = new System.Drawing.Size(150, 48);
            this.Seller.TabIndex = 16;
            this.Seller.Text = "Product";
            this.Seller.UseVisualStyleBackColor = false;
            // 
            // SellerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1329, 653);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Seller);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SellerForm";
            this.Text = "SellerForm";
            this.Load += new System.EventHandler(this.SellerForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sellerDVD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox comboBox2;
        private Guna.UI2.WinForms.Guna2DataGridView sellerDVD;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private Bunifu.UI.WinForms.BunifuTextBox sTel;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuTextBox sEmail;
        private System.Windows.Forms.Label label4;
        private Bunifu.UI.WinForms.BunifuTextBox sName;
        private System.Windows.Forms.Label label3;
        private Bunifu.UI.WinForms.BunifuTextBox sId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Seller;
        private Bunifu.UI.WinForms.BunifuTextBox sPass;
        private System.Windows.Forms.Label label6;
    }
}