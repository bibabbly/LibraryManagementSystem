﻿namespace FirstDesktopApplication
{
    partial class CategoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CategoryForm));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties33 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties34 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties35 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties36 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.catDvd = new Guna.UI2.WinForms.Guna2DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.catDesc = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.catName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.catId = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Seller = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.catDvd)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkOrange;
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.catDvd);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.catDesc);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.catName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.catId);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(176, 34);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1126, 603);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.DarkOrange;
            this.button6.Location = new System.Drawing.Point(884, 67);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(125, 36);
            this.button6.TabIndex = 20;
            this.button6.Text = "REFRESH";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.ForeColor = System.Drawing.Color.DarkOrange;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Admin",
            "Seller"});
            this.comboBox2.Location = new System.Drawing.Point(652, 67);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(213, 29);
            this.comboBox2.TabIndex = 19;
            this.comboBox2.Text = "Select Role";
            // 
            // catDvd
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            this.catDvd.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.catDvd.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.catDvd.BackgroundColor = System.Drawing.Color.White;
            this.catDvd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.catDvd.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.catDvd.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.catDvd.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.catDvd.ColumnHeadersHeight = 25;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.catDvd.DefaultCellStyle = dataGridViewCellStyle9;
            this.catDvd.EnableHeadersVisualStyles = false;
            this.catDvd.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.catDvd.Location = new System.Drawing.Point(442, 114);
            this.catDvd.Name = "catDvd";
            this.catDvd.RowHeadersVisible = false;
            this.catDvd.RowHeadersWidth = 51;
            this.catDvd.RowTemplate.Height = 24;
            this.catDvd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.catDvd.Size = new System.Drawing.Size(630, 468);
            this.catDvd.TabIndex = 18;
            this.catDvd.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.catDvd.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.catDvd.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.catDvd.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.catDvd.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.catDvd.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.catDvd.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.catDvd.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.catDvd.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.catDvd.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.catDvd.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.catDvd.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.catDvd.ThemeStyle.HeaderStyle.Height = 25;
            this.catDvd.ThemeStyle.ReadOnly = false;
            this.catDvd.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.catDvd.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.catDvd.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.catDvd.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.catDvd.ThemeStyle.RowsStyle.Height = 24;
            this.catDvd.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.catDvd.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.catDvd.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.catDvd_CellContentClick);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.DarkOrange;
            this.button5.Location = new System.Drawing.Point(231, 355);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(139, 48);
            this.button5.TabIndex = 17;
            this.button5.Text = "DELETE";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.DarkOrange;
            this.button4.Location = new System.Drawing.Point(113, 355);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 48);
            this.button4.TabIndex = 16;
            this.button4.Text = "EDIT";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DarkOrange;
            this.button3.Location = new System.Drawing.Point(13, 355);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 48);
            this.button3.TabIndex = 15;
            this.button3.Text = "ADD";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // catDesc
            // 
            this.catDesc.AcceptsReturn = false;
            this.catDesc.AcceptsTab = false;
            this.catDesc.AnimationSpeed = 200;
            this.catDesc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.catDesc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.catDesc.AutoSizeHeight = true;
            this.catDesc.BackColor = System.Drawing.Color.DarkOrange;
            this.catDesc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("catDesc.BackgroundImage")));
            this.catDesc.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.catDesc.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.catDesc.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.catDesc.BorderColorIdle = System.Drawing.Color.White;
            this.catDesc.BorderRadius = 10;
            this.catDesc.BorderThickness = 4;
            this.catDesc.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.catDesc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.catDesc.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.catDesc.DefaultText = "";
            this.catDesc.FillColor = System.Drawing.Color.DarkOrange;
            this.catDesc.HideSelection = true;
            this.catDesc.IconLeft = null;
            this.catDesc.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.catDesc.IconPadding = 10;
            this.catDesc.IconRight = null;
            this.catDesc.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.catDesc.Lines = new string[0];
            this.catDesc.Location = new System.Drawing.Point(163, 178);
            this.catDesc.MaxLength = 32767;
            this.catDesc.MinimumSize = new System.Drawing.Size(1, 1);
            this.catDesc.Modified = false;
            this.catDesc.Multiline = false;
            this.catDesc.Name = "catDesc";
            stateProperties25.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catDesc.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.catDesc.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catDesc.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.White;
            stateProperties28.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties28.ForeColor = System.Drawing.Color.Empty;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catDesc.OnIdleState = stateProperties28;
            this.catDesc.Padding = new System.Windows.Forms.Padding(3);
            this.catDesc.PasswordChar = '\0';
            this.catDesc.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.catDesc.PlaceholderText = "Enter text";
            this.catDesc.ReadOnly = false;
            this.catDesc.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.catDesc.SelectedText = "";
            this.catDesc.SelectionLength = 0;
            this.catDesc.SelectionStart = 0;
            this.catDesc.ShortcutsEnabled = true;
            this.catDesc.Size = new System.Drawing.Size(181, 48);
            this.catDesc.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.catDesc.TabIndex = 11;
            this.catDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.catDesc.TextMarginBottom = 0;
            this.catDesc.TextMarginLeft = 3;
            this.catDesc.TextMarginTop = 1;
            this.catDesc.TextPlaceholder = "Enter text";
            this.catDesc.UseSystemPasswordChar = false;
            this.catDesc.WordWrap = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkOrange;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 27);
            this.label4.TabIndex = 10;
            this.label4.Text = "DESCRIPTION";
            // 
            // catName
            // 
            this.catName.AcceptsReturn = false;
            this.catName.AcceptsTab = false;
            this.catName.AnimationSpeed = 200;
            this.catName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.catName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.catName.AutoSizeHeight = true;
            this.catName.BackColor = System.Drawing.Color.DarkOrange;
            this.catName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("catName.BackgroundImage")));
            this.catName.BorderColorActive = System.Drawing.Color.White;
            this.catName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.catName.BorderColorHover = System.Drawing.Color.White;
            this.catName.BorderColorIdle = System.Drawing.Color.White;
            this.catName.BorderRadius = 10;
            this.catName.BorderThickness = 4;
            this.catName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.catName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.catName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.catName.DefaultText = "";
            this.catName.FillColor = System.Drawing.Color.DarkOrange;
            this.catName.HideSelection = true;
            this.catName.IconLeft = null;
            this.catName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.catName.IconPadding = 10;
            this.catName.IconRight = null;
            this.catName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.catName.Lines = new string[0];
            this.catName.Location = new System.Drawing.Point(163, 124);
            this.catName.MaxLength = 32767;
            this.catName.MinimumSize = new System.Drawing.Size(1, 1);
            this.catName.Modified = false;
            this.catName.Multiline = false;
            this.catName.Name = "catName";
            stateProperties29.BorderColor = System.Drawing.Color.White;
            stateProperties29.FillColor = System.Drawing.Color.Empty;
            stateProperties29.ForeColor = System.Drawing.Color.Empty;
            stateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catName.OnActiveState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties30.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties30.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.catName.OnDisabledState = stateProperties30;
            stateProperties31.BorderColor = System.Drawing.Color.White;
            stateProperties31.FillColor = System.Drawing.Color.Empty;
            stateProperties31.ForeColor = System.Drawing.Color.Empty;
            stateProperties31.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catName.OnHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.White;
            stateProperties32.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties32.ForeColor = System.Drawing.Color.Empty;
            stateProperties32.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catName.OnIdleState = stateProperties32;
            this.catName.Padding = new System.Windows.Forms.Padding(3);
            this.catName.PasswordChar = '\0';
            this.catName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.catName.PlaceholderText = "Enter text";
            this.catName.ReadOnly = false;
            this.catName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.catName.SelectedText = "";
            this.catName.SelectionLength = 0;
            this.catName.SelectionStart = 0;
            this.catName.ShortcutsEnabled = true;
            this.catName.Size = new System.Drawing.Size(181, 46);
            this.catName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.catName.TabIndex = 9;
            this.catName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.catName.TextMarginBottom = 0;
            this.catName.TextMarginLeft = 3;
            this.catName.TextMarginTop = 1;
            this.catName.TextPlaceholder = "Enter text";
            this.catName.UseSystemPasswordChar = false;
            this.catName.WordWrap = true;
            this.catName.TextChanged += new System.EventHandler(this.bunifuTextBox2_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkOrange;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 27);
            this.label3.TabIndex = 8;
            this.label3.Text = "NAME";
            // 
            // catId
            // 
            this.catId.AcceptsReturn = false;
            this.catId.AcceptsTab = false;
            this.catId.AnimationSpeed = 200;
            this.catId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.catId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.catId.AutoSizeHeight = true;
            this.catId.BackColor = System.Drawing.Color.DarkOrange;
            this.catId.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("catId.BackgroundImage")));
            this.catId.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.catId.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.catId.BorderColorHover = System.Drawing.Color.White;
            this.catId.BorderColorIdle = System.Drawing.Color.White;
            this.catId.BorderRadius = 10;
            this.catId.BorderThickness = 4;
            this.catId.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.catId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.catId.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.catId.DefaultText = "";
            this.catId.FillColor = System.Drawing.Color.DarkOrange;
            this.catId.HideSelection = true;
            this.catId.IconLeft = null;
            this.catId.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.catId.IconPadding = 10;
            this.catId.IconRight = null;
            this.catId.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.catId.Lines = new string[0];
            this.catId.Location = new System.Drawing.Point(163, 61);
            this.catId.MaxLength = 32767;
            this.catId.MinimumSize = new System.Drawing.Size(1, 1);
            this.catId.Modified = false;
            this.catId.Multiline = false;
            this.catId.Name = "catId";
            stateProperties33.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties33.FillColor = System.Drawing.Color.Empty;
            stateProperties33.ForeColor = System.Drawing.Color.Empty;
            stateProperties33.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catId.OnActiveState = stateProperties33;
            stateProperties34.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties34.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties34.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.catId.OnDisabledState = stateProperties34;
            stateProperties35.BorderColor = System.Drawing.Color.White;
            stateProperties35.FillColor = System.Drawing.Color.Empty;
            stateProperties35.ForeColor = System.Drawing.Color.Empty;
            stateProperties35.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catId.OnHoverState = stateProperties35;
            stateProperties36.BorderColor = System.Drawing.Color.White;
            stateProperties36.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties36.ForeColor = System.Drawing.Color.Empty;
            stateProperties36.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.catId.OnIdleState = stateProperties36;
            this.catId.Padding = new System.Windows.Forms.Padding(3);
            this.catId.PasswordChar = '\0';
            this.catId.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.catId.PlaceholderText = "Enter text";
            this.catId.ReadOnly = false;
            this.catId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.catId.SelectedText = "";
            this.catId.SelectionLength = 0;
            this.catId.SelectionStart = 0;
            this.catId.ShortcutsEnabled = true;
            this.catId.Size = new System.Drawing.Size(181, 55);
            this.catId.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.catId.TabIndex = 7;
            this.catId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.catId.TextMarginBottom = 0;
            this.catId.TextMarginLeft = 3;
            this.catId.TextMarginTop = 1;
            this.catId.TextPlaceholder = "Enter text";
            this.catId.UseSystemPasswordChar = false;
            this.catId.WordWrap = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkOrange;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 27);
            this.label2.TabIndex = 6;
            this.label2.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkOrange;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(435, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 37);
            this.label1.TabIndex = 5;
            this.label1.Text = "MANAGE CATEGORIES";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkOrange;
            this.label8.Location = new System.Drawing.Point(1262, -6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 37);
            this.label8.TabIndex = 23;
            this.label8.Text = "X";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkOrange;
            this.button1.Location = new System.Drawing.Point(6, 210);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 50);
            this.button1.TabIndex = 26;
            this.button1.Text = "Selling";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DarkOrange;
            this.button2.Location = new System.Drawing.Point(12, 154);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(144, 50);
            this.button2.TabIndex = 25;
            this.button2.Text = "Seller";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Seller
            // 
            this.Seller.BackColor = System.Drawing.SystemColors.Control;
            this.Seller.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seller.ForeColor = System.Drawing.Color.DarkOrange;
            this.Seller.Location = new System.Drawing.Point(15, 82);
            this.Seller.Name = "Seller";
            this.Seller.Size = new System.Drawing.Size(141, 48);
            this.Seller.TabIndex = 24;
            this.Seller.Text = "Product";
            this.Seller.UseVisualStyleBackColor = false;
            this.Seller.Click += new System.EventHandler(this.Seller_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkOrange;
            this.label5.Location = new System.Drawing.Point(12, 579);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 37);
            this.label5.TabIndex = 38;
            this.label5.Text = "Logout";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // CategoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1314, 703);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Seller);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CategoryForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CategoryForm";
            this.Load += new System.EventHandler(this.CategoryForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.catDvd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox comboBox2;
        private Guna.UI2.WinForms.Guna2DataGridView catDvd;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private Bunifu.UI.WinForms.BunifuTextBox catDesc;
        private System.Windows.Forms.Label label4;
        private Bunifu.UI.WinForms.BunifuTextBox catName;
        private System.Windows.Forms.Label label3;
        private Bunifu.UI.WinForms.BunifuTextBox catId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Seller;
        private System.Windows.Forms.Label label5;
    }
}