﻿namespace FirstDesktopApplication
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductForm));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.catSearch = new System.Windows.Forms.ComboBox();
            this.prodDvd = new Guna.UI2.WinForms.Guna2DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.prodCategory = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.prodPrice = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.prodQty = new Bunifu.UI.WinForms.BunifuTextBox();
            this.slsls = new System.Windows.Forms.Label();
            this.prodName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.prodId = new Bunifu.UI.WinForms.BunifuTextBox();
            this.labpro = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Seller = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prodDvd)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AllowDrop = true;
            this.panel1.BackColor = System.Drawing.Color.DarkOrange;
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.catSearch);
            this.panel1.Controls.Add(this.prodDvd);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.prodCategory);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.prodPrice);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.prodQty);
            this.panel1.Controls.Add(this.slsls);
            this.panel1.Controls.Add(this.prodName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.prodId);
            this.panel1.Controls.Add(this.labpro);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(173, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1129, 603);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.DarkOrange;
            this.button6.Location = new System.Drawing.Point(884, 67);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(125, 36);
            this.button6.TabIndex = 20;
            this.button6.Text = "REFRESH";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // catSearch
            // 
            this.catSearch.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.catSearch.ForeColor = System.Drawing.Color.DarkOrange;
            this.catSearch.FormattingEnabled = true;
            this.catSearch.Location = new System.Drawing.Point(652, 67);
            this.catSearch.Name = "catSearch";
            this.catSearch.Size = new System.Drawing.Size(213, 29);
            this.catSearch.TabIndex = 19;
            this.catSearch.Text = "Select Category";
            this.catSearch.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            this.catSearch.SelectionChangeCommitted += new System.EventHandler(this.catSearch_SelectionChangeCommitted);
            // 
            // prodDvd
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.prodDvd.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.prodDvd.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.prodDvd.BackgroundColor = System.Drawing.Color.White;
            this.prodDvd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.prodDvd.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.prodDvd.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.prodDvd.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.prodDvd.ColumnHeadersHeight = 25;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.prodDvd.DefaultCellStyle = dataGridViewCellStyle3;
            this.prodDvd.EnableHeadersVisualStyles = false;
            this.prodDvd.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.prodDvd.Location = new System.Drawing.Point(442, 114);
            this.prodDvd.Name = "prodDvd";
            this.prodDvd.RowHeadersVisible = false;
            this.prodDvd.RowHeadersWidth = 51;
            this.prodDvd.RowTemplate.Height = 24;
            this.prodDvd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.prodDvd.Size = new System.Drawing.Size(630, 468);
            this.prodDvd.TabIndex = 18;
            this.prodDvd.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.prodDvd.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.prodDvd.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.prodDvd.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.prodDvd.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.prodDvd.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.prodDvd.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.prodDvd.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.prodDvd.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.prodDvd.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.prodDvd.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.prodDvd.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.prodDvd.ThemeStyle.HeaderStyle.Height = 25;
            this.prodDvd.ThemeStyle.ReadOnly = false;
            this.prodDvd.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.prodDvd.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.prodDvd.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.prodDvd.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.prodDvd.ThemeStyle.RowsStyle.Height = 24;
            this.prodDvd.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.prodDvd.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.prodDvd.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.prodDvd_CellContentClick);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.DarkOrange;
            this.button5.Location = new System.Drawing.Point(231, 355);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(122, 48);
            this.button5.TabIndex = 17;
            this.button5.Text = "DELETE";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.DarkOrange;
            this.button4.Location = new System.Drawing.Point(113, 355);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 48);
            this.button4.TabIndex = 16;
            this.button4.Text = "EDIT";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DarkOrange;
            this.button3.Location = new System.Drawing.Point(13, 355);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 48);
            this.button3.TabIndex = 15;
            this.button3.Text = "ADD";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // prodCategory
            // 
            this.prodCategory.DisplayMember = "catName";
            this.prodCategory.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prodCategory.ForeColor = System.Drawing.Color.DarkOrange;
            this.prodCategory.FormattingEnabled = true;
            this.prodCategory.Location = new System.Drawing.Point(149, 292);
            this.prodCategory.Name = "prodCategory";
            this.prodCategory.Size = new System.Drawing.Size(182, 29);
            this.prodCategory.TabIndex = 15;
            this.prodCategory.Text = "Select Category";
            this.prodCategory.ValueMember = "catName";
            this.prodCategory.SelectedIndexChanged += new System.EventHandler(this.prodCategory_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkOrange;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(8, 290);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 27);
            this.label6.TabIndex = 14;
            this.label6.Text = "CATEGORY";
            // 
            // prodPrice
            // 
            this.prodPrice.AcceptsReturn = false;
            this.prodPrice.AcceptsTab = false;
            this.prodPrice.AnimationSpeed = 200;
            this.prodPrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.prodPrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.prodPrice.AutoSizeHeight = true;
            this.prodPrice.BackColor = System.Drawing.Color.DarkOrange;
            this.prodPrice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("prodPrice.BackgroundImage")));
            this.prodPrice.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.prodPrice.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.prodPrice.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.prodPrice.BorderColorIdle = System.Drawing.Color.White;
            this.prodPrice.BorderRadius = 10;
            this.prodPrice.BorderThickness = 4;
            this.prodPrice.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.prodPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.prodPrice.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.prodPrice.DefaultText = "";
            this.prodPrice.FillColor = System.Drawing.Color.DarkOrange;
            this.prodPrice.HideSelection = true;
            this.prodPrice.IconLeft = null;
            this.prodPrice.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodPrice.IconPadding = 10;
            this.prodPrice.IconRight = null;
            this.prodPrice.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodPrice.Lines = new string[0];
            this.prodPrice.Location = new System.Drawing.Point(149, 232);
            this.prodPrice.MaxLength = 32767;
            this.prodPrice.MinimumSize = new System.Drawing.Size(1, 1);
            this.prodPrice.Modified = false;
            this.prodPrice.Multiline = false;
            this.prodPrice.Name = "prodPrice";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodPrice.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.prodPrice.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodPrice.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.White;
            stateProperties4.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodPrice.OnIdleState = stateProperties4;
            this.prodPrice.Padding = new System.Windows.Forms.Padding(3);
            this.prodPrice.PasswordChar = '\0';
            this.prodPrice.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.prodPrice.PlaceholderText = "Enter text";
            this.prodPrice.ReadOnly = false;
            this.prodPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.prodPrice.SelectedText = "";
            this.prodPrice.SelectionLength = 0;
            this.prodPrice.SelectionStart = 0;
            this.prodPrice.ShortcutsEnabled = true;
            this.prodPrice.Size = new System.Drawing.Size(181, 38);
            this.prodPrice.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.prodPrice.TabIndex = 13;
            this.prodPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.prodPrice.TextMarginBottom = 0;
            this.prodPrice.TextMarginLeft = 3;
            this.prodPrice.TextMarginTop = 1;
            this.prodPrice.TextPlaceholder = "Enter text";
            this.prodPrice.UseSystemPasswordChar = false;
            this.prodPrice.WordWrap = true;
            this.prodPrice.TextChanged += new System.EventHandler(this.bunifuTextBox4_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkOrange;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 27);
            this.label5.TabIndex = 12;
            this.label5.Text = "PRICE";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // prodQty
            // 
            this.prodQty.AcceptsReturn = false;
            this.prodQty.AcceptsTab = false;
            this.prodQty.AnimationSpeed = 200;
            this.prodQty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.prodQty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.prodQty.AutoSizeHeight = true;
            this.prodQty.BackColor = System.Drawing.Color.DarkOrange;
            this.prodQty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("prodQty.BackgroundImage")));
            this.prodQty.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.prodQty.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.prodQty.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.prodQty.BorderColorIdle = System.Drawing.Color.White;
            this.prodQty.BorderRadius = 10;
            this.prodQty.BorderThickness = 4;
            this.prodQty.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.prodQty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.prodQty.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.prodQty.DefaultText = "";
            this.prodQty.FillColor = System.Drawing.Color.DarkOrange;
            this.prodQty.HideSelection = true;
            this.prodQty.IconLeft = null;
            this.prodQty.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodQty.IconPadding = 10;
            this.prodQty.IconRight = null;
            this.prodQty.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodQty.Lines = new string[0];
            this.prodQty.Location = new System.Drawing.Point(149, 188);
            this.prodQty.MaxLength = 32767;
            this.prodQty.MinimumSize = new System.Drawing.Size(1, 1);
            this.prodQty.Modified = false;
            this.prodQty.Multiline = false;
            this.prodQty.Name = "prodQty";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodQty.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.prodQty.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodQty.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.White;
            stateProperties8.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodQty.OnIdleState = stateProperties8;
            this.prodQty.Padding = new System.Windows.Forms.Padding(3);
            this.prodQty.PasswordChar = '\0';
            this.prodQty.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.prodQty.PlaceholderText = "Enter text";
            this.prodQty.ReadOnly = false;
            this.prodQty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.prodQty.SelectedText = "";
            this.prodQty.SelectionLength = 0;
            this.prodQty.SelectionStart = 0;
            this.prodQty.ShortcutsEnabled = true;
            this.prodQty.Size = new System.Drawing.Size(181, 38);
            this.prodQty.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.prodQty.TabIndex = 11;
            this.prodQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.prodQty.TextMarginBottom = 0;
            this.prodQty.TextMarginLeft = 3;
            this.prodQty.TextMarginTop = 1;
            this.prodQty.TextPlaceholder = "Enter text";
            this.prodQty.UseSystemPasswordChar = false;
            this.prodQty.WordWrap = true;
            this.prodQty.TextChanged += new System.EventHandler(this.bunifuTextBox3_TextChanged);
            // 
            // slsls
            // 
            this.slsls.AutoSize = true;
            this.slsls.BackColor = System.Drawing.Color.DarkOrange;
            this.slsls.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slsls.ForeColor = System.Drawing.Color.White;
            this.slsls.Location = new System.Drawing.Point(3, 199);
            this.slsls.Name = "slsls";
            this.slsls.Size = new System.Drawing.Size(107, 27);
            this.slsls.TabIndex = 10;
            this.slsls.Text = "Quantity";
            this.slsls.Click += new System.EventHandler(this.label4_Click);
            // 
            // prodName
            // 
            this.prodName.AcceptsReturn = false;
            this.prodName.AcceptsTab = false;
            this.prodName.AnimationSpeed = 200;
            this.prodName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.prodName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.prodName.AutoSizeHeight = true;
            this.prodName.BackColor = System.Drawing.Color.DarkOrange;
            this.prodName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("prodName.BackgroundImage")));
            this.prodName.BorderColorActive = System.Drawing.Color.White;
            this.prodName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.prodName.BorderColorHover = System.Drawing.Color.White;
            this.prodName.BorderColorIdle = System.Drawing.Color.White;
            this.prodName.BorderRadius = 10;
            this.prodName.BorderThickness = 4;
            this.prodName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.prodName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.prodName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.prodName.DefaultText = "";
            this.prodName.FillColor = System.Drawing.Color.DarkOrange;
            this.prodName.HideSelection = true;
            this.prodName.IconLeft = null;
            this.prodName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodName.IconPadding = 10;
            this.prodName.IconRight = null;
            this.prodName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodName.Lines = new string[0];
            this.prodName.Location = new System.Drawing.Point(149, 132);
            this.prodName.MaxLength = 32767;
            this.prodName.MinimumSize = new System.Drawing.Size(1, 1);
            this.prodName.Modified = false;
            this.prodName.Multiline = false;
            this.prodName.Name = "prodName";
            stateProperties9.BorderColor = System.Drawing.Color.White;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodName.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.prodName.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.White;
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodName.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.White;
            stateProperties12.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodName.OnIdleState = stateProperties12;
            this.prodName.Padding = new System.Windows.Forms.Padding(3);
            this.prodName.PasswordChar = '\0';
            this.prodName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.prodName.PlaceholderText = "Enter text";
            this.prodName.ReadOnly = false;
            this.prodName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.prodName.SelectedText = "";
            this.prodName.SelectionLength = 0;
            this.prodName.SelectionStart = 0;
            this.prodName.ShortcutsEnabled = true;
            this.prodName.Size = new System.Drawing.Size(181, 38);
            this.prodName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.prodName.TabIndex = 9;
            this.prodName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.prodName.TextMarginBottom = 0;
            this.prodName.TextMarginLeft = 3;
            this.prodName.TextMarginTop = 1;
            this.prodName.TextPlaceholder = "Enter text";
            this.prodName.UseSystemPasswordChar = false;
            this.prodName.WordWrap = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkOrange;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 27);
            this.label3.TabIndex = 8;
            this.label3.Text = "NAME";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // prodId
            // 
            this.prodId.AcceptsReturn = false;
            this.prodId.AcceptsTab = false;
            this.prodId.AnimationSpeed = 200;
            this.prodId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.prodId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.prodId.AutoSizeHeight = true;
            this.prodId.BackColor = System.Drawing.Color.DarkOrange;
            this.prodId.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("prodId.BackgroundImage")));
            this.prodId.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.prodId.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.prodId.BorderColorHover = System.Drawing.Color.White;
            this.prodId.BorderColorIdle = System.Drawing.Color.White;
            this.prodId.BorderRadius = 10;
            this.prodId.BorderThickness = 4;
            this.prodId.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.prodId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.prodId.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.prodId.DefaultText = "";
            this.prodId.FillColor = System.Drawing.Color.DarkOrange;
            this.prodId.HideSelection = true;
            this.prodId.IconLeft = null;
            this.prodId.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodId.IconPadding = 10;
            this.prodId.IconRight = null;
            this.prodId.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.prodId.Lines = new string[0];
            this.prodId.Location = new System.Drawing.Point(149, 78);
            this.prodId.MaxLength = 32767;
            this.prodId.MinimumSize = new System.Drawing.Size(1, 1);
            this.prodId.Modified = false;
            this.prodId.Multiline = false;
            this.prodId.Name = "prodId";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodId.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.prodId.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.White;
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodId.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.White;
            stateProperties16.FillColor = System.Drawing.Color.DarkOrange;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.prodId.OnIdleState = stateProperties16;
            this.prodId.Padding = new System.Windows.Forms.Padding(3);
            this.prodId.PasswordChar = '\0';
            this.prodId.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.prodId.PlaceholderText = "Enter text";
            this.prodId.ReadOnly = false;
            this.prodId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.prodId.SelectedText = "";
            this.prodId.SelectionLength = 0;
            this.prodId.SelectionStart = 0;
            this.prodId.ShortcutsEnabled = true;
            this.prodId.Size = new System.Drawing.Size(181, 38);
            this.prodId.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.prodId.TabIndex = 7;
            this.prodId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.prodId.TextMarginBottom = 0;
            this.prodId.TextMarginLeft = 3;
            this.prodId.TextMarginTop = 1;
            this.prodId.TextPlaceholder = "Enter text";
            this.prodId.UseSystemPasswordChar = false;
            this.prodId.WordWrap = true;
            this.prodId.TextChanged += new System.EventHandler(this.bunifuTextBox1_TextChanged);
            // 
            // labpro
            // 
            this.labpro.AutoSize = true;
            this.labpro.BackColor = System.Drawing.Color.DarkOrange;
            this.labpro.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labpro.ForeColor = System.Drawing.Color.White;
            this.labpro.Location = new System.Drawing.Point(3, 89);
            this.labpro.Name = "labpro";
            this.labpro.Size = new System.Drawing.Size(34, 27);
            this.labpro.TabIndex = 6;
            this.labpro.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkOrange;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(435, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(294, 37);
            this.label1.TabIndex = 5;
            this.label1.Text = "MANAGE PRODUCT";
            // 
            // Seller
            // 
            this.Seller.BackColor = System.Drawing.SystemColors.Control;
            this.Seller.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seller.ForeColor = System.Drawing.Color.DarkOrange;
            this.Seller.Location = new System.Drawing.Point(12, 140);
            this.Seller.Name = "Seller";
            this.Seller.Size = new System.Drawing.Size(150, 48);
            this.Seller.TabIndex = 1;
            this.Seller.Text = "Seller";
            this.Seller.UseVisualStyleBackColor = false;
            this.Seller.Click += new System.EventHandler(this.Seller_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DarkOrange;
            this.button2.Location = new System.Drawing.Point(12, 194);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 50);
            this.button2.TabIndex = 2;
            this.button2.Text = "Categories";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkOrange;
            this.button1.Location = new System.Drawing.Point(12, 250);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 50);
            this.button1.TabIndex = 3;
            this.button1.Text = "Selling";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkOrange;
            this.label8.Location = new System.Drawing.Point(1265, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 37);
            this.label8.TabIndex = 14;
            this.label8.Text = "X";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.DarkOrange;
            this.button7.Location = new System.Drawing.Point(12, 564);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(150, 50);
            this.button7.TabIndex = 15;
            this.button7.Text = "Logout";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // ProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1314, 687);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Seller);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProductForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProductForm";
            this.Load += new System.EventHandler(this.ProductForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prodDvd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Seller;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labpro;
        private Bunifu.UI.WinForms.BunifuTextBox prodId;
        private Bunifu.UI.WinForms.BunifuTextBox prodName;
        private System.Windows.Forms.Label label3;
        private Bunifu.UI.WinForms.BunifuTextBox prodQty;
        private System.Windows.Forms.Label slsls;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox catSearch;
        private Guna.UI2.WinForms.Guna2DataGridView prodDvd;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox prodCategory;
        private Bunifu.UI.WinForms.BunifuTextBox prodPrice;
        private System.Windows.Forms.Button button7;
    }
}